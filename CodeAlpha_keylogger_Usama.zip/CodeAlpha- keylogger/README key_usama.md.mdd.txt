# CodeAlpha_Keylogger

## Keylogger Tool - Cyber Security Internship Task 2

This is a simple Python-based keylogger created for educational and internship learning purposes.  
The script captures keystrokes and stores them in a `log.txt` file on the Desktop.

### Technologies Used
- Python 3
- pynput library

### How It Works
- Listens to keyboard events using `pynput.keyboard.Listener`
- Logs all pressed keys into a text file (`log.txt`)
- Special keys like Enter, Space, Backspace are recorded in readable format

### Setup Instructions

1. Install the Required Library

pip install pynput



2. Run the Script

python keylogger.py



3. View Output

- Check your Desktop for a file named `log.txt`
- All typed text (even outside VS Code) will be recorded in that file

Note: This project is for ethical learning only. Do not use it for unauthorized tracking or surveillance.

---

### Author 
Muhammad Usama
LinkedIn: https://www.linkedin.com/in/muhammad-usama-21561a289?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app  
This project was completed as part of the CodeAlpha Cyber Security Internship.
